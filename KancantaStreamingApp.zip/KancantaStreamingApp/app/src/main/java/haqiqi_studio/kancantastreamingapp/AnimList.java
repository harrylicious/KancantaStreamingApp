package haqiqi_studio.kancantastreamingapp;


import android.app.ActionBar;
import android.app.Activity;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.widget.SearchView;

import haqiqi_studio.kancantastreamingapp.Anim.AnimationClasses;


public class AnimList extends FragmentActivity
{

    private int mShortAnimationDuration;

    ViewGroup container, container1;
     int a,b;
    int hasil;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anim_list);





    }




}


