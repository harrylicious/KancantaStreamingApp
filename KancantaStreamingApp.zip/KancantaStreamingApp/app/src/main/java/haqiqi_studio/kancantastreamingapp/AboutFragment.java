package haqiqi_studio.kancantastreamingapp;


import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.transition.Transition;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import haqiqi_studio.kancantastreamingapp.Anim.AnimationClasses;
import haqiqi_studio.kancantastreamingapp.Classes.Utils;
import haqiqi_studio.kancantastreamingapp.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class AboutFragment extends Fragment {

    Button btnPass, wa;
    Dialog dialog;
    ImageView close, send;
    TextView nama, alamat;

    public AboutFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_about, container, false);

        Button sendToEmail = getActivity().findViewById(R.id.dialog_btn_send);
        final MultiAutoCompleteTextView text = v.findViewById(R.id.dialog_txt_msg);

        btnPass = v.findViewById(R.id.shareBtnFB);
        send = v.findViewById(R.id.home_img_send);
        wa = v.findViewById(R.id.shareBtnWa);
        nama = v.findViewById(R.id.txtPerusahaan);
        alamat = v.findViewById(R.id.txtPerusahaanAlamat);
        dialog = new Dialog(getContext());

        nama.setSelected(true);
        alamat.setSelected(true);



      try {
          sendToEmail.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  new Utils().composeEmail("kancanta_fm@yahoo.co.id",text.getText().toString());
              }
          });
      }
      catch (Exception e) {
          e.printStackTrace();
      }



        btnPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(btnPass, "Succes!", Snackbar.LENGTH_SHORT).show();
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopup(v);
                Snackbar.make(btnPass, "Sent!", Snackbar.LENGTH_SHORT).show();
            }
        });

        return v;
    }

    public void showPopup(View v) {

        dialog.setContentView(R.layout.dialog_msg);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(5);
            dialog.getWindow().setClipToOutline(false);
        }

        dialog.show();
    }




}
